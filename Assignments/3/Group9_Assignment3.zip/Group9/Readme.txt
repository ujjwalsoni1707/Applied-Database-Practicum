The php files in PDO folder connects with mysql server using php data objects and the php files in the other folder connects using MySQLi. Both the folders have the same html/css files.

The location in the header() function used in the php files needs to be changed depending upon the exact location of the files in the system.
